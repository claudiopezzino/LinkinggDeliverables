import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GoogleTranslate {

    public String fromItalianToEnglish(String italianSentence) {

        /*-- Variables --*/
        String translation;
        /*---------------*/

        /*--------------------- Prepare google site ------------------------*/
        System.setProperty("webdriver.chrome.driver", "driver/chromedriver");
        WebDriver driver = new ChromeDriver();
        driver.get("https://translate.google.it/?hl=it&sl=it&tl=en&op=translate");
        /*------------------------------------------------------------------*/

        /*----------------------------------------- Accept coockies ---------------------------------------------------------------------- */
        driver.findElement(By.xpath("//*[@id=\"yDmH0d\"]/c-wiz/div/div/div/div[2]/div[1]/div[4]/div[1]/div[1]/form[2]/div/div/button/span")).
                click();
        /*---------------------------------------------------------------------------------------------------------------------------------*/

        /*------------------------------------------------- Type sendKeys content ----------------------------------------------------*/
        driver.findElement(By.
                        xpath("//*[@id=\"yDmH0d\"]/c-wiz/div/div[2]/c-wiz/div[2]/c-wiz/div[1]/div[2]/div[3]/c-wiz[1]/span/span/div/textarea")).
                sendKeys(italianSentence);
        /*----------------------------------------------------------------------------------------------------------------------------*/

        /*--------------------------------------------------------------- Wait till translation is available ----------------------------------------------------------*/
        WebElement result = new WebDriverWait(driver, Long.parseLong("2"))
                .until(ExpectedConditions.
                        presenceOfElementLocated(
                                By.xpath("//*[@id=\"yDmH0d\"]/c-wiz/div/div[2]/c-wiz/div[2]/c-wiz/div[1]/div[2]/div[3]/c-wiz[2]/div/div[8]/div/div[1]/span[1]/span/span")
                        )
                );
        /*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

        /*- Fetch translation result -*/
        translation = result.getText();
        /*-----------------------------*/

        /*Close connection*/
        driver.close();
        /*-------------*/

        /*---- Result ----*/
        return translation;
        /*----------------*/

    }

}

