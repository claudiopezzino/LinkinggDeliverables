import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TestGoogleTranslate {
    @Test
    void testTranslation() {

        String myItalianSentence = "Oggi è il giorno dell'esame";
        String myTranslatedSentence = "Today is the day of the exam";

        GoogleTranslate gt = new GoogleTranslate();
        String googleTranslation = gt.fromItalianToEnglish(myItalianSentence);

        assertEquals(myTranslatedSentence, googleTranslation);
    }
}

